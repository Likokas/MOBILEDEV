package com.example.likokas_17;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class Delete extends AppCompatActivity {

    int del = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_detail);

        ArrayList<User> arrayList = SaveData.DataUser;

        TextView input_name, input_age, input_address;


        input_name = findViewById(R.id.display_name);
        input_age = findViewById(R.id.display_age);
        input_address = findViewById(R.id.display_alamat);

        Intent intent = getIntent();

        int position = intent.getIntExtra("position", 0);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar2);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });



        input_name.setText(arrayList.get(position).getNama());
        input_age.setText(arrayList.get(position).getUmur() + " years old");
        input_address.setText(arrayList.get(position).getAlamat());

    }

    public void hapus(View view) {


        if(del == 1) {
            hapus2();
        }else{
            alertMessage();
        }

    }

    public void hapus2(){
        ArrayList<User> arrayList = SaveData.DataUser;


        int position = getIntent().getIntExtra("position", 0);

        arrayList.remove(position);

        Intent intent2 = new Intent(Delete.this, MainActivity.class);
        startActivity(intent2);
        finish();
    }

    public void edit(View view) {

        ArrayList<User> arrayList = SaveData.DataUser;
        int position = getIntent().getIntExtra("position", 0);

        Intent intent2 = new Intent(Delete.this, EditUser.class);
        intent2.putExtra("arrayList", arrayList);
        intent2.putExtra("position", position);
        intent2.putExtra("check_edit", 1);
        startActivity(intent2);
        finish();
    }

    public void alertMessage(){
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:

                        del = 1;
                        hapus2();
                        Toast.makeText(Delete.this, "Delete Berhasil", Toast.LENGTH_LONG).show();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:

                        del = 0;
                        dialog.dismiss();

                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Yakin?")
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }
}
