package com.example.likokas_17;

import java.util.ArrayList;

public class SaveData {

    public static ArrayList<User> DataUser = new ArrayList<>();
}
