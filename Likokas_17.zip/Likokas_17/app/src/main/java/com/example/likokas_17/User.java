package com.example.likokas_17;

import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {

    private String Nama;
    private String Umur;
    private String Alamat;

    public User(String nama, String umur, String alamat) {
        this.Nama = nama;
        this.Umur = umur;
        this.Alamat = alamat;
    }

    protected User(Parcel in) {
        Nama = in.readString();
        Umur = in.readString();
        Alamat = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        this.Nama = nama;
    }

    public String getUmur() {
        return Umur;
    }

    public void setUmur(String umur) {
        this.Umur = umur;
    }

    public String getAlamat() {
        return Alamat;
    }

    public void setAlamat(String alamat) {
        this.Alamat = alamat;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Nama);
        dest.writeString(Umur);
        dest.writeString(Alamat);
    }
}
