package com.example.likokas_17;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder>{

    ArrayList<User> ArrayList;
    private OnCardListener OnCardListener;

    public UserAdapter(ArrayList<User> users, OnCardListener onCardListener){
        this.ArrayList = users;
        this.OnCardListener = onCardListener;
    }
    public UserAdapter() {

    }

    public ArrayList<User> getArrayList() {
        return ArrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view, OnCardListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.Name.setText(ArrayList.get(position).getNama());
        holder.Ages.setText(ArrayList.get(position).getUmur() + " years old");
        holder.Address.setText(ArrayList.get(position).getAlamat());
    }

    @Override
    public int getItemCount() {
        return ArrayList.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView Name, Ages, Address;
        OnCardListener onCardListener;

        public MyViewHolder(@NonNull View itemView, OnCardListener onCardListener) {
            super(itemView);
            Name = itemView.findViewById(R.id.display_name);
            Ages = itemView.findViewById(R.id.display_age);
            Address = itemView.findViewById(R.id.display_alamat);
            this.onCardListener = onCardListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            onCardListener.onCardClick(getAdapterPosition());
        }
    }

    public interface OnCardListener {
        void onCardClick (int position);
    }
}
