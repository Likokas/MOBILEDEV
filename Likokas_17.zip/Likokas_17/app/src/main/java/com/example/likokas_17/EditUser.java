package com.example.likokas_17;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

public class EditUser extends AppCompatActivity implements TextWatcher {

    Toolbar toolbar;
    TextInputLayout input_nama, input_umur, input_alamat;
    TextInputEditText text_nama, text_umur,text_alamat;
    Button button_add;

    String name, age, address;
    ProgressDialog progressDialog;

    boolean edit = false;
    int home = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        toolbar = findViewById(R.id.toolbar3);
        input_nama = findViewById(R.id.input_nama);
        input_umur = findViewById(R.id.input_umur);
        input_alamat = findViewById(R.id.display_alamat);
        button_add = findViewById(R.id.button_add);

        text_nama = findViewById(R.id.text_nama);
        text_umur = findViewById(R.id.text_umur);
        text_alamat = findViewById(R.id.text_alamat);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(EditUser.this, MainActivity.class);
                home = 0;
                startActivity(intent);
                finish();
            }
        });

        final int position = getIntent().getIntExtra("position", 0);
        ArrayList<User> arrayList = SaveData.DataUser;
        final int check_edit = getIntent().getIntExtra("check_edit", 0);


        if(check_edit == 0){
            System.out.println("error");
            toolbar.setTitle("Add User");
        }else{
            text_nama.setText(arrayList.get(position).getNama());
            text_umur.setText(arrayList.get(position).getUmur());
            text_alamat.setText(arrayList.get(position).getAlamat());
            edit = true;
            toolbar.setTitle("Edit User");
        }

        input_nama.getEditText().addTextChangedListener(this);
        input_umur.getEditText().addTextChangedListener(this);
        input_alamat.getEditText().addTextChangedListener(this);


        button_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog = new ProgressDialog(EditUser.this);
                progressDialog.setMessage("Loading...");
                progressDialog.setTitle("ProgressDialog");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.show();
                progressDialog.setCancelable(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(10000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        progressDialog.dismiss();
                    }
                }).start();
                User user = new User(name, age, address);
                Intent intent = new Intent(EditUser.this, MainActivity.class);
                if(edit == true){
                    intent = new Intent(EditUser.this, Delete.class);
                }
                intent.putExtra("dataUser", user);
                if(edit == false){
                    SaveData.DataUser.add(user);
                }else{
                    SaveData.DataUser.set(position, user);
                }
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        name = input_nama.getEditText().getText().toString().trim();
        age = input_umur.getEditText().getText().toString().trim();
        address = input_alamat.getEditText().getText().toString().trim();
        if (!name.isEmpty() && !age.isEmpty() && !address.isEmpty()) {
            button_add.setEnabled(true);
        } else {

            button_add.setEnabled(false);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    @Override
    public void onStop() {

        super.onStop();
        if (home == 1){
            progressDialog.dismiss();
        }
    }
}
